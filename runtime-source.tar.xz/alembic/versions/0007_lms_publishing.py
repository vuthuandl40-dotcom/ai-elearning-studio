"""Step 9 SCORM/LMS publishing profile

Revision ID: 0007
Revises: 0006
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0007"
down_revision: Union[str, None] = "0006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "lms_publish_profiles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("default_standard", sa.String(length=24), nullable=False, server_default="scorm2004"),
        sa.Column("passing_score", sa.Integer(), nullable=False, server_default="80"),
        sa.Column("completion_threshold", sa.Numeric(4, 3), nullable=False, server_default="1.0"),
        sa.Column("track_interactions", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("resume_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("report_session_time", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("settings", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.CheckConstraint("passing_score >= 0 AND passing_score <= 100", name="ck_lms_profile_passing_score"),
        sa.CheckConstraint("completion_threshold >= 0 AND completion_threshold <= 1", name="ck_lms_profile_completion_threshold"),
        sa.UniqueConstraint("project_id", name="uq_lms_publish_profile_project"),
    )
    op.create_index("ix_lms_publish_profiles_project_id", "lms_publish_profiles", ["project_id"])


def downgrade() -> None:
    op.drop_index("ix_lms_publish_profiles_project_id", table_name="lms_publish_profiles")
    op.drop_table("lms_publish_profiles")

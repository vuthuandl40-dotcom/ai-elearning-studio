"""Initial AI E-Learning Studio schema.

Revision ID: 0001
Revises: 
"""
from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

DDL = r"""
-- AI E-Learning Studio — Step 1 Database Foundation
-- PostgreSQL 15+ recommended. pgvector is optional but enabled for source-first RAG.

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS app_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id TEXT UNIQUE,
    email TEXT UNIQUE,
    display_name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    subject TEXT,
    grade TEXT,
    education_level TEXT,
    book_series TEXT,
    duration_minutes INTEGER CHECK (duration_minutes IS NULL OR duration_minutes > 0),
    lesson_periods INTEGER NOT NULL DEFAULT 1 CHECK (lesson_periods > 0),
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','analyzing','planned','generating','editing','reviewed','completed','archived')),
    language TEXT NOT NULL DEFAULT 'vi',
    visual_style TEXT,
    narration_style TEXT,
    interaction_level TEXT CHECK (interaction_level IS NULL OR interaction_level IN ('low','medium','high')),
    source_policy TEXT NOT NULL DEFAULT 'strict' CHECK (source_policy IN ('strict','source_plus_verified','open')),
    extra_instructions TEXT,
    settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);

CREATE TABLE IF NOT EXISTS source_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    original_name TEXT NOT NULL,
    storage_uri TEXT,
    mime_type TEXT,
    size_bytes BIGINT,
    sha256 TEXT,
    parse_status TEXT NOT NULL DEFAULT 'pending' CHECK (parse_status IN ('pending','processing','ready','failed')),
    page_count INTEGER,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_source_files_project_id ON source_files(project_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_source_files_project_sha256
    ON source_files(project_id, sha256) WHERE sha256 IS NOT NULL;

-- Parsed chunks are the evidence layer used by AI agents.
CREATE TABLE IF NOT EXISTS source_chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_file_id UUID NOT NULL REFERENCES source_files(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    page_start INTEGER,
    page_end INTEGER,
    heading TEXT,
    content TEXT NOT NULL,
    token_count INTEGER,
    embedding VECTOR(1536),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(source_file_id, chunk_index)
);

CREATE INDEX IF NOT EXISTS idx_source_chunks_project_id ON source_chunks(project_id);
CREATE INDEX IF NOT EXISTS idx_source_chunks_source_file_id ON source_chunks(source_file_id);

CREATE TABLE IF NOT EXISTS lesson_objectives (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    objective_order INTEGER NOT NULL,
    objective_text TEXT NOT NULL,
    cognitive_level TEXT,
    objective_type TEXT NOT NULL DEFAULT 'learning' CHECK (objective_type IN ('learning','knowledge','skill','attitude','competency')),
    source_chunk_ids UUID[] NOT NULL DEFAULT '{}',
    is_teacher_approved BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(project_id, objective_order)
);

CREATE INDEX IF NOT EXISTS idx_objectives_project_id ON lesson_objectives(project_id);

CREATE TABLE IF NOT EXISTS teacher_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    reference_image_uri TEXT,
    appearance_description TEXT,
    hair_description TEXT,
    clothing_description TEXT,
    visual_style TEXT,
    age_appearance TEXT,
    negative_rules TEXT,
    voice_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
    character_lock JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_teacher_profiles_user_id ON teacher_profiles(user_id);

CREATE TABLE IF NOT EXISTS lesson_sections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    section_key TEXT NOT NULL,
    section_order INTEGER NOT NULL CHECK (section_order BETWEEN 1 AND 15),
    title TEXT NOT NULL,
    purpose TEXT,
    is_required BOOLEAN NOT NULL DEFAULT TRUE,
    is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    teacher_approved BOOLEAN NOT NULL DEFAULT FALSE,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(project_id, section_key),
    UNIQUE(project_id, section_order)
);

CREATE INDEX IF NOT EXISTS idx_sections_project_id ON lesson_sections(project_id);

CREATE TABLE IF NOT EXISTS slides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    section_id UUID NOT NULL REFERENCES lesson_sections(id) ON DELETE CASCADE,
    slide_order INTEGER NOT NULL,
    title TEXT,
    slide_type TEXT NOT NULL DEFAULT 'content',
    onscreen_text JSONB NOT NULL DEFAULT '[]'::jsonb,
    teacher_script TEXT,
    student_instruction TEXT,
    visual_type TEXT,
    visual_description TEXT,
    image_prompt TEXT,
    video_prompt TEXT,
    duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds >= 0),
    layout_hint TEXT,
    media JSONB NOT NULL DEFAULT '[]'::jsonb,
    ai_metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    teacher_approved BOOLEAN NOT NULL DEFAULT FALSE,
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(project_id, slide_order)
);

CREATE INDEX IF NOT EXISTS idx_slides_project_id ON slides(project_id);
CREATE INDEX IF NOT EXISTS idx_slides_section_id ON slides(section_id);

CREATE TABLE IF NOT EXISTS interactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slide_id UUID NOT NULL REFERENCES slides(id) ON DELETE CASCADE,
    interaction_type TEXT NOT NULL CHECK (interaction_type IN ('single_choice','multiple_choice','true_false','fill_blank','matching','drag_drop')),
    question TEXT NOT NULL,
    options JSONB NOT NULL DEFAULT '[]'::jsonb,
    correct_answer JSONB NOT NULL,
    correct_feedback TEXT,
    incorrect_feedback TEXT,
    explanation TEXT,
    difficulty TEXT CHECK (difficulty IS NULL OR difficulty IN ('remember','understand','apply','analyze')),
    points NUMERIC(6,2) NOT NULL DEFAULT 1,
    settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_interactions_slide_id ON interactions(slide_id);

-- Trace every generated factual slide back to evidence chunks.
CREATE TABLE IF NOT EXISTS slide_source_refs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slide_id UUID NOT NULL REFERENCES slides(id) ON DELETE CASCADE,
    source_chunk_id UUID NOT NULL REFERENCES source_chunks(id) ON DELETE CASCADE,
    claim_text TEXT,
    relevance_score NUMERIC(5,4),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(slide_id, source_chunk_id, claim_text)
);

CREATE INDEX IF NOT EXISTS idx_slide_source_refs_slide_id ON slide_source_refs(slide_id);
CREATE INDEX IF NOT EXISTS idx_slide_source_refs_chunk_id ON slide_source_refs(source_chunk_id);

CREATE TABLE IF NOT EXISTS ai_reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    review_type TEXT NOT NULL DEFAULT 'full',
    total_score NUMERIC(5,2),
    knowledge_score NUMERIC(5,2),
    pedagogy_score NUMERIC(5,2),
    interaction_score NUMERIC(5,2),
    multimedia_score NUMERIC(5,2),
    structure_score NUMERIC(5,2),
    findings JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_reviews_project_id ON ai_reviews(project_id);

-- Generic updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['app_users','projects','source_files','lesson_objectives','teacher_profiles','lesson_sections','slides','interactions']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_%I_updated_at ON %I;', t, t);
    EXECUTE format('CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION set_updated_at();', t, t);
  END LOOP;
END $$;

"""

def upgrade() -> None:
    op.execute(DDL)

def downgrade() -> None:
    op.execute("""
    DROP TABLE IF EXISTS ai_reviews CASCADE;
    DROP TABLE IF EXISTS slide_source_refs CASCADE;
    DROP TABLE IF EXISTS interactions CASCADE;
    DROP TABLE IF EXISTS slides CASCADE;
    DROP TABLE IF EXISTS lesson_sections CASCADE;
    DROP TABLE IF EXISTS teacher_profiles CASCADE;
    DROP TABLE IF EXISTS lesson_objectives CASCADE;
    DROP TABLE IF EXISTS source_chunks CASCADE;
    DROP TABLE IF EXISTS source_files CASCADE;
    DROP TABLE IF EXISTS projects CASCADE;
    DROP TABLE IF EXISTS app_users CASCADE;
    DROP FUNCTION IF EXISTS set_updated_at() CASCADE;
    """)

"""assessment analytics and learner tracking

Revision ID: 0008
Revises: 0007
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "learner_attempts",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("learner_key", sa.Text(), nullable=False),
        sa.Column("learner_name", sa.Text()),
        sa.Column("external_attempt_id", sa.Text()),
        sa.Column("source", sa.String(24), nullable=False, server_default="direct"),
        sa.Column("status", sa.String(24), nullable=False, server_default="in_progress"),
        sa.Column("score_raw", sa.Numeric(7, 2)),
        sa.Column("score_scaled", sa.Numeric(6, 5)),
        sa.Column("progress", sa.Numeric(6, 5), nullable=False, server_default="0"),
        sa.Column("completed", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("success", sa.Boolean()),
        sa.Column("duration_seconds", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("session_count", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("metadata", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("last_event_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("project_id", "external_attempt_id", name="uq_attempt_external_id"),
        sa.CheckConstraint("progress >= 0 AND progress <= 1", name="ck_attempt_progress"),
    )
    op.create_index("ix_learner_attempts_project_id", "learner_attempts", ["project_id"])
    op.create_index("ix_learner_attempts_learner_key", "learner_attempts", ["learner_key"])

    op.create_table(
        "learner_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("attempt_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("learner_attempts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_type", sa.String(32), nullable=False),
        sa.Column("event_id", sa.Text()),
        sa.Column("verb_iri", sa.Text()),
        sa.Column("slide_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("slides.id", ondelete="SET NULL")),
        sa.Column("interaction_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("interactions.id", ondelete="SET NULL")),
        sa.Column("objective_ids", postgresql.ARRAY(postgresql.UUID(as_uuid=True)), nullable=False, server_default="{}"),
        sa.Column("response", postgresql.JSONB()),
        sa.Column("correct", sa.Boolean()),
        sa.Column("score_raw", sa.Numeric(7, 2)),
        sa.Column("score_scaled", sa.Numeric(6, 5)),
        sa.Column("progress", sa.Numeric(6, 5)),
        sa.Column("duration_seconds", sa.Integer()),
        sa.Column("payload", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("event_time", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.UniqueConstraint("attempt_id", "event_id", name="uq_attempt_event_id"),
    )
    op.create_index("ix_learner_events_attempt_id", "learner_events", ["attempt_id"])
    op.create_index("ix_learner_events_project_id", "learner_events", ["project_id"])
    op.create_index("ix_learner_events_event_type", "learner_events", ["event_type"])

    op.create_table(
        "lrs_connections",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("endpoint", sa.Text()),
        sa.Column("xapi_version", sa.String(24), nullable=False, server_default="1.0.3"),
        sa.Column("auth_type", sa.String(16), nullable=False, server_default="none"),
        sa.Column("username_env", sa.Text()),
        sa.Column("password_env", sa.Text()),
        sa.Column("token_env", sa.Text()),
        sa.Column("verify_tls", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("timeout_seconds", sa.Integer(), nullable=False, server_default="15"),
        sa.Column("settings", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_lrs_connections_project_id", "lrs_connections", ["project_id"])

    op.create_table(
        "lrs_deliveries",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("projects.id", ondelete="CASCADE"), nullable=False),
        sa.Column("attempt_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("learner_attempts.id", ondelete="SET NULL")),
        sa.Column("status", sa.String(24), nullable=False, server_default="processing"),
        sa.Column("statement_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("http_status", sa.Integer()),
        sa.Column("response_excerpt", sa.Text()),
        sa.Column("error_message", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_lrs_deliveries_project_id", "lrs_deliveries", ["project_id"])


def downgrade():
    op.drop_table("lrs_deliveries")
    op.drop_table("lrs_connections")
    op.drop_table("learner_events")
    op.drop_table("learner_attempts")

"""Visual Composer design state and media assets.

Revision ID: 0005
Revises: 0004
"""
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
    ALTER TABLE slides ADD COLUMN IF NOT EXISTS design_json JSONB NOT NULL DEFAULT '{}'::jsonb;

    CREATE TABLE IF NOT EXISTS media_assets (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        slide_id UUID REFERENCES slides(id) ON DELETE SET NULL,
        asset_type TEXT NOT NULL CHECK (asset_type IN ('image','video','audio','document','other')),
        status TEXT NOT NULL DEFAULT 'ready' CHECK (status IN ('ready','prompt_ready','generating','failed')),
        original_name TEXT,
        storage_uri TEXT,
        mime_type TEXT,
        size_bytes BIGINT,
        prompt TEXT,
        provider TEXT,
        provider_asset_id TEXT,
        width INTEGER,
        height INTEGER,
        duration_seconds INTEGER,
        metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
        error_message TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_media_assets_project_id ON media_assets(project_id);
    CREATE INDEX IF NOT EXISTS idx_media_assets_slide_id ON media_assets(slide_id);
    """)


def downgrade() -> None:
    op.execute("""
    DROP TABLE IF EXISTS media_assets CASCADE;
    ALTER TABLE slides DROP COLUMN IF EXISTS design_json;
    """)

"""Pedagogy Planner runs and planning lifecycle.

Revision ID: 0003
Revises: 0002
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
    ALTER TABLE projects DROP CONSTRAINT IF EXISTS projects_status_check;
    ALTER TABLE projects
      ADD CONSTRAINT projects_status_check
      CHECK (status IN ('draft','analyzing','analyzed','planning','plan_ready','planned','generating','editing','reviewed','completed','archived'));

    CREATE TABLE IF NOT EXISTS planning_runs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        analysis_run_id UUID REFERENCES analysis_runs(id) ON DELETE SET NULL,
        status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing','completed','failed')),
        planner_version TEXT NOT NULL,
        planning_mode TEXT NOT NULL CHECK (planning_mode IN ('ai','local')),
        plan_json JSONB NOT NULL DEFAULT '{}'::jsonb,
        warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
        error_message TEXT,
        teacher_approved BOOLEAN NOT NULL DEFAULT FALSE,
        approved_at TIMESTAMPTZ,
        started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        completed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_planning_runs_project_id ON planning_runs(project_id);
    CREATE INDEX IF NOT EXISTS idx_planning_runs_analysis_run_id ON planning_runs(analysis_run_id);
    """)


def downgrade() -> None:
    op.execute("""
    DROP TABLE IF EXISTS planning_runs CASCADE;
    ALTER TABLE projects DROP CONSTRAINT IF EXISTS projects_status_check;
    ALTER TABLE projects
      ADD CONSTRAINT projects_status_check
      CHECK (status IN ('draft','analyzing','analyzed','planned','generating','editing','reviewed','completed','archived'));
    """)

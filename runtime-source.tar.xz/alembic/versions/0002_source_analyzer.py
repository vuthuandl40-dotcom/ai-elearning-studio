"""Source Analyzer runs and analyzed project status.

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
    ALTER TABLE projects DROP CONSTRAINT IF EXISTS projects_status_check;
    ALTER TABLE projects
      ADD CONSTRAINT projects_status_check
      CHECK (status IN ('draft','analyzing','analyzed','planned','generating','editing','reviewed','completed','archived'));

    CREATE TABLE IF NOT EXISTS analysis_runs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing','completed','failed')),
        analyzer_version TEXT NOT NULL,
        analysis_mode TEXT NOT NULL CHECK (analysis_mode IN ('ai','local')),
        file_count INTEGER NOT NULL DEFAULT 0,
        chunk_count INTEGER NOT NULL DEFAULT 0,
        knowledge_map JSONB NOT NULL DEFAULT '{}'::jsonb,
        warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
        error_message TEXT,
        started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        completed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_analysis_runs_project_id ON analysis_runs(project_id);
    """)


def downgrade() -> None:
    op.execute("""
    DROP TABLE IF EXISTS analysis_runs CASCADE;
    ALTER TABLE projects DROP CONSTRAINT IF EXISTS projects_status_check;
    ALTER TABLE projects
      ADD CONSTRAINT projects_status_check
      CHECK (status IN ('draft','analyzing','planned','generating','editing','reviewed','completed','archived'));
    """)

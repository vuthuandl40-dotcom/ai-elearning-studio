"""Lesson Writer generation runs and slide provenance.

Revision ID: 0004
Revises: 0003
"""
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
    CREATE TABLE IF NOT EXISTS generation_runs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        planning_run_id UUID REFERENCES planning_runs(id) ON DELETE SET NULL,
        status TEXT NOT NULL DEFAULT 'processing' CHECK (status IN ('processing','completed','failed')),
        writer_version TEXT NOT NULL,
        generation_mode TEXT NOT NULL CHECK (generation_mode IN ('ai','local')),
        generation_json JSONB NOT NULL DEFAULT '{}'::jsonb,
        warnings JSONB NOT NULL DEFAULT '[]'::jsonb,
        error_message TEXT,
        slide_count INTEGER NOT NULL DEFAULT 0 CHECK (slide_count >= 0),
        source_ref_count INTEGER NOT NULL DEFAULT 0 CHECK (source_ref_count >= 0),
        teacher_approved BOOLEAN NOT NULL DEFAULT FALSE,
        approved_at TIMESTAMPTZ,
        started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        completed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS idx_generation_runs_project_id ON generation_runs(project_id);
    CREATE INDEX IF NOT EXISTS idx_generation_runs_planning_run_id ON generation_runs(planning_run_id);

    ALTER TABLE slides ADD COLUMN IF NOT EXISTS generation_run_id UUID REFERENCES generation_runs(id) ON DELETE SET NULL;
    CREATE INDEX IF NOT EXISTS idx_slides_generation_run_id ON slides(generation_run_id);
    """)


def downgrade() -> None:
    op.execute("""
    DROP INDEX IF EXISTS idx_slides_generation_run_id;
    ALTER TABLE slides DROP COLUMN IF EXISTS generation_run_id;
    DROP TABLE IF EXISTS generation_runs CASCADE;
    """)
